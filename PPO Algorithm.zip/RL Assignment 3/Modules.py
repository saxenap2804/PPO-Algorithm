# modules.py
import torch
import torch.nn as nn
import torch.distributions as distributions

# 1. Policy network: Outputs mean and std of a Gaussian distribution for actions.
class PolicyNetwork(nn.Module):
    def __init__(self, obs_dim, act_dim, hidden_sizes):
        super().__init__()
        layers = []
        # Hidden layers
        for in_size, out_size in zip([obs_dim] + hidden_sizes[:-1], hidden_sizes):
            layers.append(nn.Linear(in_size, out_size))
            layers.append(nn.ReLU())
        # Final layer outputs action mean
        layers.append(nn.Linear(hidden_sizes[-1], act_dim))
        self.mean = nn.Sequential(*layers)
        # Log std parameter (state-independent variance for simplicity)
        self.log_std = nn.Parameter(-0.5 * torch.ones(act_dim))

    def forward(self, obs):
        # Computes action mean and std
        mean = self.mean(obs)
        std = torch.exp(self.log_std)
        return mean, std

    def get_action(self, obs):
        # Samples an action from the policy and returns the log probability
        mean, std = self(obs)
        dist = distributions.Normal(mean, std)
        action = dist.sample()
        log_prob = dist.log_prob(action).sum(axis=-1)
        return action.detach().numpy(), log_prob.detach()

# 2. Value network: Outputs the state value (scalar).
class ValueNetwork(nn.Module):
    def __init__(self, obs_dim, hidden_sizes):
        super().__init__()
        layers = []
        # Hidden layers
        for in_size, out_size in zip([obs_dim] + hidden_sizes[:-1], hidden_sizes):
            layers.append(nn.Linear(in_size, out_size))
            layers.append(nn.ReLU())
        # Final layer outputs a single scalar (state value)
        layers.append(nn.Linear(hidden_sizes[-1], 1))
        self.net = nn.Sequential(*layers)

    def forward(self, obs):
        # Outputs the scalar value of a state
        return self.net(obs).squeeze(-1)
